package com.intermarche.edge.domain.setting;

import io.quarkus.hibernate.orm.panache.PanacheEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

import java.util.List;

/**
 * An administered DOCUMENT TEMPLATE: the layout of one printed document, stated
 * as a Qute template and edited in the back office (BO-03-03).
 *
 * <p>THE DECISION THIS EMBODIES. The register already ships a Qute engine, so a
 * template engine did not have to be written — the layout of a document becomes
 * a template like every screen of the application, stored in a row instead of a
 * file. Adding a line to the receipt is then a paragraph typed in the back
 * office, not a delivery.
 *
 * <p>WHAT A TEMPLATE CAN SEE, and this is the whole safety of the design: the
 * renderer hands it MAPS, LISTS AND STRINGS — never an entity. Every amount,
 * rate, quantity and date arrives already written, exactly as
 * {@code InvoiceDocument} already does for the two renderers it feeds. A
 * template therefore lays out and nothing else: it cannot call a method on a
 * sale, cannot reach the database, and cannot format a decimal one way while
 * the rest of the register formats it another.
 *
 * <p>A document type no row administers is printed by the register's own code,
 * unchanged. That is what lets the referential be installed on a running shop
 * one document at a time.
 */
@Entity
@Table(name = "document_template")
public class DocumentTemplate extends PanacheEntity {

    /** The narrowest roll a template may declare, in characters. */
    public static final int MIN_WIDTH = 20;

    /** The widest page a template may declare, in characters. */
    public static final int MAX_WIDTH = 120;

    /** The stable technical code of the template (for example, TICKET_VENTE_FR). */
    @Column(name = "code", unique = true, nullable = false, length = 50)
    public String code;

    /** The human-readable label shown in the back office. */
    @Column(name = "label", nullable = false, length = 100)
    public String label;

    /** The document this template lays out. */
    @Enumerated(EnumType.STRING)
    @Column(name = "document_type", nullable = false, length = 30)
    public DocumentType documentType;

    /** Whether the template is used; deactivated, never deleted. */
    @Column(name = "active", nullable = false)
    public boolean active = true;

    /** The order competing templates of one document type are tried in. */
    @Column(name = "priority", nullable = false)
    public int priority = 100;

    /** The width the template lays out for, in characters. */
    @Column(name = "width", nullable = false)
    public int width = 42;

    /** How many copies of the document are printed (BO-03-02-33). */
    @Column(name = "copies", nullable = false)
    public int copies = 1;

    /** The Qute source the back office edits. */
    @Lob
    @Column(name = "source", nullable = false)
    public String source;

    /**
     * The NAME this document carries when it is printed (BO-03-04-12), blank
     * when the register's own wording stands.
     *
     * <p>Beside the layout and not inside it, because a shop that keeps the
     * built-in document may still want to rename it — a "TICKET DE RETOUR"
     * called "BON DE REPRISE" is the same paper under another name, and
     * rewriting the whole layout to change two words is not a reasonable
     * price.
     */
    @Column(name = "title", length = 60)
    public String title;

    /**
     * The NAME this document carries when it is REPRINTED (BO-03-04-13), blank
     * when the register's own wording stands.
     *
     * <p>A separate word from the one above, because the two are not the same
     * statement: Portugal prints DUPLICADO where France prints DUPLICATA, and
     * a shop renaming its document does not thereby rename its reprints.
     */
    @Column(name = "duplicate_title", length = 60)
    public String duplicateTitle;

    /**
     * The PREFIX the document's number carries (BO-03-04-22), blank when the
     * register's own numbering stands.
     *
     * <p>Portugal identifies a document series by its prefix — FT, NC, RC —
     * and the counter is kept per prefix, so this column is what makes two
     * series of the same register two series.
     */
    @Column(name = "number_prefix", length = 20)
    public String numberPrefix;

    /**
     * The name of EACH printed copy, in order, separated by semicolons
     * (BO-03-04-24, -25 and -26); blank when the register's own wording
     * stands.
     *
     * <p>{@code ORIGINAL;DUPLICADO;TRIPLICADO} is the Portuguese case, and it
     * is a LIST and not three columns because the number of copies is itself
     * administered: a document printed twice names two copies, one printed
     * three times names three, and nothing in the code decides how many there
     * are.
     */
    @Column(name = "copy_titles", length = 200)
    public String copyTitles;

    /**
     * Tells whether the template carries a source worth rendering.
     *
     * <p>A row saved with an empty source is not an error and not a reason to
     * print nothing: it is a template the paramétreur has not written yet, and
     * the register goes on printing the document its own way.
     *
     * @return true when the template has something to render
     */
    public boolean isRenderable() {
        return active && source != null && !source.isBlank();
    }



    /**
     * Returns the active templates of one document type, in administered order.
     *
     * @param type the document type, or null
     * @return the templates, empty when the type is administered by none
     */
    public static List<DocumentTemplate> listActiveFor(DocumentType type) {
        if (type == null) {
            return List.of();
        }
        return list("active = true and documentType = ?1 order by priority, code", type);
    }

    /**
     * Returns the template that lays out a document type, or null when the
     * register lays it out itself.
     *
     * @param type the document type, or null
     * @return the first renderable active template, or null when there is none
     */
    public static DocumentTemplate findFor(DocumentType type) {
        for (DocumentTemplate template : listActiveFor(type)) {
            if (template != null && template.isRenderable()) {
                return template;
            }
        }
        return null;
    }

    /**
     * The administered NAME of a document type, or null when the register's own
     * wording stands (BO-03-04-12).
     *
     * <p>Read off the ACTIVE rows whatever their source: a shop may rename a
     * document it has not restated, and a row carrying a name and no layout is
     * exactly that case. The first non-blank name in administered order wins,
     * the same order the layout is picked in.
     *
     * @param type the document type, or null
     * @return the administered name, or null when there is none
     */
    public static String titleFor(DocumentType type) {
        for (DocumentTemplate template : listActiveFor(type)) {
            if (template != null && template.title != null && !template.title.isBlank()) {
                return template.title.trim();
            }
        }
        return null;
    }

    /**
     * The administered name of a document type WHEN REPRINTED, or null when the
     * register's own wording stands (BO-03-04-13).
     *
     * @param type the document type, or null
     * @return the administered reprint name, or null when there is none
     */
    public static String duplicateTitleFor(DocumentType type) {
        for (DocumentTemplate template : listActiveFor(type)) {
            if (template != null && template.duplicateTitle != null
                    && !template.duplicateTitle.isBlank()) {
                return template.duplicateTitle.trim();
            }
        }
        return null;
    }

    /**
     * The administered PREFIX of a document type's number, or null when the
     * register's own numbering stands (BO-03-04-22).
     *
     * @param type the document type, or null
     * @return the prefix, or null when there is none
     */
    public static String prefixFor(DocumentType type) {
        for (DocumentTemplate template : listActiveFor(type)) {
            if (template != null && template.numberPrefix != null
                    && !template.numberPrefix.isBlank()) {
                return template.numberPrefix.trim();
            }
        }
        return null;
    }

    /**
     * The administered name of the COPY of the given rank, or null when none is
     * administered for that rank (BO-03-04-24, -25 and -26).
     *
     * <p>Rank one is the original. A rank beyond the names administered answers
     * null rather than the last name: printing a fourth copy called TRIPLICADO
     * would state something false on a fiscal document.
     *
     * @param type the document type, or null
     * @param rank the copy's rank, one-based
     * @return the copy's name, or null
     */
    public static String copyTitleFor(DocumentType type, int rank) {
        if (rank < 1) {
            return null;
        }
        for (DocumentTemplate template : listActiveFor(type)) {
            if (template == null || template.copyTitles == null
                    || template.copyTitles.isBlank()) {
                continue;
            }
            String[] names = template.copyTitles.split(";", -1);
            if (rank > names.length || names[rank - 1].isBlank()) {
                continue;
            }
            return names[rank - 1].trim();
        }
        return null;
    }

    /**
     * Returns every administered template, active or not, in administered order.
     *
     * @return the whole referential, empty when nothing is administered
     */
    public static List<DocumentTemplate> listAllOrdered() {
        return list("order by documentType, priority, code");
    }

    /**
     * Returns the administered template of the given code.
     *
     * @param code the technical code, or null
     * @return the template, or null when no row carries that code
     */
    public static DocumentTemplate findByCode(String code) {
        if (code == null || code.isBlank()) {
            return null;
        }
        return find("code", code.trim()).firstResult();
    }

    /**
     * The documents the register prints and a template may lay out (BO-03-03).
     *
     * <p>One constant per document the register actually emits today: the list
     * is deliberately closed, because a template for a document nothing prints
     * would be a row nobody ever reads.
     */
    public enum DocumentType {

        /** The sale receipt. */
        SALE_RECEIPT("Ticket de vente"),

        /**
         * PORTUGAL — {@code fatura simplificada}, the simplified invoice a
         * register hands over for an ordinary sale (BO-03-04-21).
         *
         * <p>The four fiscal types below are DOCUMENTS LIKE THE OTHERS: their
         * layout is a gabarit, their copies are the gabarit's {@code copies},
         * the name of each copy is in {@code copyTitles}, and their number
         * comes from the sequence the register keeps per type, per register,
         * per point of sale and per year. Nothing about them is written in
         * Java, which is what lets a country be opened without a release.
         */
        FS("Portugal — Fatura simplificada (FS)"),

        /** PORTUGAL — {@code fatura}, the full invoice, printed in three copies (BO-03-04-24). */
        FT("Portugal — Fatura (FT)"),

        /** PORTUGAL — {@code nota de crédito}, the credit note, two copies naming the document it corrects. */
        NC("Portugal — Nota de crédito (NC)"),

        /** PORTUGAL — {@code recibo}, the receipt of settlement, one copy. */
        RC("Portugal — Recibo (RC)"),

        /**
         * A ZONE — a piece of layout a document includes rather than repeats
         * (BO-03-04-03, -04 and -07).
         *
         * <p>Not a document: nothing prints a fragment on its own. A document
         * names it with {@code [[ZONE <code>]]} and the renderer puts the
         * fragment's source there before parsing, so the zones of a document
         * are the placeholders its source carries, in the order it carries
         * them — which is both the "les unes derrière les autres" the
         * questionnaire asks for and the placed position it asks for next.
         *
         * <p>Being a template like the others, a zone gets the administration
         * screen, the compilation check, the preview and the referential pull
         * for free; several zones under different codes are several MODELS of
         * the same zone, and a document picks the one it names.
         */
        FRAGMENT("Zone de document"),

        /**
         * The administered HEAD of the sale receipt (BO-03-05-01, BO-03-04-02).
         *
         * <p>A BANNER AND NOT A DOCUMENT. The receipt itself may be restated
         * whole by {@link #SALE_RECEIPT}; this one restates only the few lines
         * printed under the store address, for the shop that wants its own
         * wording there without taking over the whole ticket. It therefore
         * applies on the BUILT-IN receipt only: where the shop administers the
         * whole layout, the head is the author's business and inside their
         * source.
         *
         * <p>It replaces the single centred line of
         * {@code ticket.header-message}: a template is as many lines as the
         * shop writes, each aligned by {@code fmt.centre}, {@code fmt.right} or
         * written plain for the left.
         */
        TICKET_HEADER("Entête de ticket"),

        /** The administered FOOT of the sale receipt (BO-03-05-03), the head's twin. */
        TICKET_FOOTER("Pied de ticket"),

        /** The administered HEAD of the invoice (BO-03-05-02), the receipt head's twin. */
        INVOICE_HEADER("Entête de facture"),

        /** The administered FOOT of the invoice (BO-03-05-04), the invoice head's twin. */
        INVOICE_FOOTER("Pied de facture"),

        /** The refund receipt. */
        REFUND_RECEIPT("Ticket de retour"),

        /** The commercial invoice, as the register's own roll prints it. */
        INVOICE("Facture (rouleau)"),

        /** The X report (reading). */
        X_REPORT("Rapport X"),

        /** The Z report (closing). */
        Z_REPORT("Rapport Z"),

        /** The withdrawal ticket. */
        WITHDRAWAL_TICKET("Ticket de prélèvement"),

        /** The transfer ticket between two tenders. */
        TRANSFER_TICKET("Ticket de transfert"),

        /** The voucher printed for a freshly issued gift card. */
        GIFT_CARD_VOUCHER("Bon carte cadeau"),

        /** The voucher printed for a credit note. */
        CREDIT_NOTE_VOUCHER("Bon d'avoir"),

        /** The card receipt handed over with a settlement. */
        CARD_RECEIPT("Justificatif carte"),

        /**
         * The commercial invoice, as the network printer's A4 page states it.
         *
         * <p>A SECOND type for the same document, deliberately: the roll states
         * it in forty-two columns of text and the office printer states it as an
         * HTML page, and one source cannot be both. Two rows so that a shop
         * which restates its invoice restates it on BOTH papers — a document
         * that changed on one and not the other is an accounting defect, not an
         * ergonomic detail.
         */
        INVOICE_A4("Facture (A4 réseau)"),

        /**
         * The slip handed over with a settlement taken on the loyalty balance
         * (BO-03-03-10).
         *
         * <p>An ADDITIONAL ticket, printed after the sale receipt and not
         * instead of it: it states one settlement — the amount taken, the card
         * it was taken from and the sale it settled — which is what a customer
         * disputing a cagnotte débit comes back with.
         */
        LOYALTY_RECEIPT("Justificatif paiement fidélité"),

        /**
         * The EXIT ticket (BO-03-03-36) — a ticket printed INSTEAD OF the sale
         * receipt where the store administers it.
         *
         * <p>Substitutive and not additional, which is the whole point: a store
         * whose customers show a paper on the way out does not need the full
         * receipt in their hand, it needs the few figures a gate or a greeter
         * checks — a total, a count of articles, and the most expensive ones
         * named, so a trolley can be compared to the paper without reading
         * eighty lines.
         *
         * <p>Every value it states is DERIVED from the sale: nothing new is
         * stored, and a store that switches it off goes back to the receipt
         * with no trace left behind.
         */
        EXIT_TICKET("Ticket de sortie"),

        /**
         * The UNKNOWN-ARTICLE slip (BO-03-10-05): the paper a register prints
         * when a scanned code is recognized by nothing.
         *
         * <p>Not an error message — the screen already carries one. This is the
         * paper a department manager walks back to the referential with: the
         * code as it was read, the register, the moment. Administered per
         * ISLAND, because the self-service lane has nobody to hand it to.
         */
        UNKNOWN_ARTICLE_TICKET("Ticket article inconnu"),

        /**
         * The RESUME ticket of a parked sale (BO-03-03-07).
         *
         * <p>The parked receipt (LC-04-01-02) says what was put aside; this one
         * says that it came back, and names BOTH numbers — the ticket the sale
         * goes on with, and the number the parked paper carried. On a resume
         * taken over from another register (EXP-46) those two differ, and that
         * difference is exactly what a dispute two hours later turns on.
         */
        PARKED_TICKET_RESUME("Ticket de reprise"),

        /**
         * The slip of a CANCELLED settlement (BO-03-02-35).
         *
         * <p>A settlement undone is an event, not a non-event. The customer
         * handed over a cheque or a card and the register gave it back: the
         * paper says which tender, for how much, on which ticket and at what
         * time, so the till's journal and the customer agree on what happened.
         * The engine that renders it is the same one every other document goes
         * through — the editor comment claiming it had to be created first was
         * written before that engine existed.
         */
        PAYMENT_CANCELLATION("Ticket d'annulation de règlement"),

        /**
         * The DEPOSIT slip of a customer order (BO-03-03-09).
         *
         * <p>The money is taken before the goods exist, so the paper is the
         * customer's only proof: it names the order, the customer, the amount
         * and a unique number, and carries that number as a barcode so the
         * balance can be settled by scanning it. The deposit itself is not
         * invented here — the order referential has carried it since EXP-85
         * ({@code CustomerOrder.depositPaid}); the editor comment claiming the
         * data had to be created first was written before it did.
         */
        DEPOSIT_RECEIPT("Justificatif d'acompte"),

        /**
         * The slip of a settlement paid by GIFT CARD (BO-03-03-11).
         *
         * <p>Distinct from the gift-card VOUCHER, which is the paper handed to
         * a customer BUYING one: this is the one handed to a customer SPENDING
         * one, and what it adds is the balance the card still carries. That
         * balance is the issuer's answer, capped against the amount settled
         * (EXP-66) — it did not have to be invented either.
         */
        GIFT_CARD_PAYMENT("Justificatif paiement carte cadeau"),

        /**
         * The LOYALTY ZONE of a sale receipt, for a CARD HOLDER whose
         * programme answered during the sale (BO-10-03-05, BO-10-03-12).
         *
         * <p>Not a document of its own: a SECTION of the sale receipt, which is
         * why it states no store address and no ticket number. The register
         * prints its built-in loyalty zone until a store names a template for
         * this case, and from then on prints the template instead — the four
         * cases of BO-10-03-05 are four types rather than four branches of one,
         * so that the preview shows a paramétreur exactly the values his case
         * carries.
         */
        LOYALTY_ONLINE("Zone fidélité — porteur, programme en ligne"),

        /**
         * The LOYALTY ZONE for a CARD HOLDER whose programme did NOT answer
         * during the sale (BO-10-03-05, BO-10-03-11).
         *
         * <p>The zone that replaces advantages nobody could compute: it carries
         * the card that was read and the shop's offline wording, and never a
         * balance — a balance the programme did not state is a figure the
         * register would be inventing.
         */
        LOYALTY_OFFLINE("Zone fidélité — porteur, programme hors ligne"),

        /**
         * The LOYALTY ZONE for a customer who presented NO card while the
         * programme answered (BO-10-03-05).
         *
         * <p>This is the anonymous projection: what a card WOULD have earned.
         * It has no balance and no card number by construction, and that is the
         * whole reason it is a type apart — a template written for a holder
         * would print two empty lines here.
         */
        LOYALTY_NON_HOLDER_ONLINE("Zone fidélité — non porteur, programme en ligne"),

        /**
         * The LOYALTY ZONE for a customer who presented no card while the
         * programme was unreachable (BO-10-03-05, BO-10-03-13).
         *
         * <p>The thinnest of the four: neither advantages nor balance exist for
         * this sale, so all the zone can carry is the shop's word to someone
         * who has no card and whose programme could not be asked.
         */
        LOYALTY_NON_HOLDER_OFFLINE("Zone fidélité — non porteur, programme hors ligne");

        /** The label shown on the administration screen. */
        private final String label;

        /**
         * Builds a document type with its administration label.
         *
         * @param label the label shown on the administration screen
         */
        DocumentType(String label) {
            this.label = label;
        }

        /**
         * Returns the label shown on the administration screen.
         *
         * @return the label
         */
        public String getLabel() {
            return label;
        }
    }
}
