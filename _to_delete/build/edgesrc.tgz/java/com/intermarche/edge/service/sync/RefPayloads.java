package com.intermarche.edge.service.sync;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Referential snapshot payloads pulled by the registers from the store node
 * (phase 6 lot 3). Natural keys only, like the document synchronization:
 * family code, product EAN, employee login, coupon-type code; prices
 * reference their product by EAN. Dates travel as ISO-8601 strings.
 * <p>
 * Any field added here must also be added to the canonical string of
 * {@code RefExportService} (fingerprint input) and to the corresponding
 * apply method — the three evolve as one.
 * <p>
 * The two domain lists live here rather than on the exporter because both
 * ends read them: the store node exports those domains, the downstream node
 * pulls them. Holding them on the exporter made the pull loop — common to
 * both roles — depend on the store half of the synchronization.
 */
public final class RefPayloads {

    /**
     * Non-instantiable payload container.
     */
    private RefPayloads() {}

    /**
     * The referential domains a REGISTER pulls from its store node, in apply
     * order.
     * <p>
     * PRODUCTS comes BEFORE FAMILIES: a family payload carries the articles it
     * contains, so the articles must already exist when the family is wired.
     * Nothing points the other way — an article holds no family reference, the
     * association is owned by the family — so the swap is safe.
     */
    public static final List<String> DOMAINS =
            List.of("ENGINE_FEEDS", "PRODUCTS", "FAMILIES", "TOUCH_GROUPS", "VAT_RATES", "PRICES",
                    "EMPLOYEES", "COUPON_TYPES", "ARTICLE_RANGES", "ISLANDS", "CHECKOUT_POINTS",
                    "TENDERS",
                    "DOCUMENT_TEMPLATES", "PROVIDER_MESSAGES", "SETTINGS",
                    "CUSTOMERS", "CURRENCIES", "POSTAL_CODES", "POS_LISTS", "STORE_IMAGES");

    /**
     * The echelon domains a STORE node pulls from the CENTRAL node (route A),
     * in apply order: the organisation tree top-down (a PDV references its
     * enseigne, an enseigne its country) then the parameters posed on it. A
     * register never pulls these — it receives only the resolved SETTINGS.
     */
    public static final List<String> ECHELON_DOMAINS =
            List.of("COUNTRIES", "ENSEIGNES", "PDVS", "ECHELON_SETTINGS");

    /**
     * How one article group is drawn on the touch grid (upsert by group code).
     * <p>
     * A domain of its own, and not four more fields on {@link FamilyDto},
     * because the two have different owners and different lifetimes: the
     * nomenclature comes from the gestion commerciale and is replaced whole at
     * every integration, the touch configuration is administered in the back
     * office. Merged, re-importing the nomenclature erased the shop's grid.
     */
    public static class TouchGroupDto {
        /** The code of the group this row configures (upsert key). */
        public String familyCode;
        /** Whether the group touch is pinned (BO-03-01-07). */
        public boolean pinned;
        /** The touch size SMALL/NORMAL/LARGE (BO-03-01-08), never null. */
        public String buttonSize;
        /** The custom display rank (BO-03-01-11). */
        public int displayOrder;
        /** The sales volume for the volume order (BO-03-01-13). */
        public long salesVolume;
        /** Islands the group is drawn on (BO-03-01-21), codes split by ';', or null for all. */
        public String islandCodes;
        /** Registers the group is drawn on (BO-03-01-22), ids split by ';', or null for all. */
        public String terminalIds;
        /** Kinds of point of contact (BO-03-01-23), names split by ';', or null for all. */
        public String tpvTypes;
        /** The group's label in other languages, as lang=libellé pairs (BO-03-01-19). */
        public String labels;
    }

    /**
     * A product family (upsert by code).
     */
    public static class FamilyDto {
        /** The family code (upsert key). */
        public String code;
        /** The family description. */
        public String description;
        /** The display flags. */
        public String flags;
        /**
         * The codes of the families this one hangs under (BO-03-01-01).
         * <p>
         * A LIST, not a single parent: the model allows a family to hang under
         * several, and picking one would invent a rule the product has never
         * written. Empty for a root family.
         */
        public java.util.List<String> parentCodes = new java.util.ArrayList<>();
        /**
         * The EANs of the articles this family contains (BO-03-01-04/16).
         * <p>
         * Carried here rather than on the article, because the family owns the
         * association. Without it the register receives flat, empty groups —
         * the touch grid of a freshly pulled register would show buttons with
         * nothing behind them.
         */
        public java.util.List<String> productEans = new java.util.ArrayList<>();
    }

    /**
     * A product (upsert by EAN).
     */
    public static class ProductDto {
        /** The EAN (upsert key). */
        public String ean;
        /** The PLU, or null. */
        public String plu;
        /** The product name. */
        public String name;
        /** The description, or null. */
        public String description;
        /** The display icon, or null. */
        public String icon;
        /** The touch image as a base64 data URI, or null (BO-03-01-15). */
        public String imageData;
        /** The brand, or null. */
        public String brand;
        /** The reference weight, or null. */
        public BigDecimal referenceWeight;
        /** The reference volume, or null. */
        public BigDecimal referenceVolume;
        /** The product type name. */
        public String productType;
        /** The unit name, or null. */
        public String unitName;
        /** Whether the product is active. */
        public boolean active;
        /** Whether the product is forbidden to sale. */
        public boolean forbiddenToSale;
        /** The minimum age required to sell the article, or null (BO-02-03-08). */
        public Integer ageRestriction;
        /** The checkout label, or null (BO-02-03-02). */
        public String checkoutLabel;
        /** The message shown when the article is rung, or null (BO-03-08-09). */
        public String infoMessage;
        /** The internal code, or null (BO-02-03-04). */
        public String internalCode;
        /** True when the product is sold loose (bulk), weight known only at weighing time. */
        public boolean variableWeight;
        /**
         * The declared attributes, code&nbsp;→&nbsp;text value (BO-02-03-18).
         * A {@link TreeMap} so JSON and the canonical fingerprint are ordered
         * by key; never null (empty when the article carries no attribute).
         */
        public Map<String, String> attributes = new TreeMap<>();
    }

    /**
     * A price row (prices are replaced as a whole, no upsert key).
     */
    /**
     * One VAT regime of the referential (BO-02-03-14).
     *
     * <p>Its own domain, applied BEFORE the prices: a price names a regime by
     * its number, so the table has to exist when the price rows land.
     */
    public static class VatRateDto {
        /** The regime number, the upsert key. */
        public Integer number;
        /** The rate as a fraction, 0.0550 for five and a half percent. */
        public BigDecimal rate;
        /** What a human reads in front of the rate, or null. */
        public String label;
        /** The ISO country the regime belongs to, or null for all of them. */
        public String country;
        /** The legal mention the regime obliges the documents to carry, or null. */
        public String legalMention;
    }

    public static class PriceDto {
        /** The EAN of the priced product. */
        public String productEan;
        /** The price excluding tax. */
        public BigDecimal priceExcludingTax;
        /** The price including tax. */
        public BigDecimal priceIncludingTax;
        /**
         * The NUMBER of the VAT regime this price falls under, or null when it
         * names none. The rate itself travels in its own domain, once, instead
         * of being repeated on every price row.
         */
        public Integer vatNumber;
        /** The selection priority. */
        public Integer priority;
        /** The validity start, ISO-8601, or null. */
        public String startDateTime;
        /** The validity end, ISO-8601, or null. */
        public String endDateTime;
    }

    /**
     * An employee (upsert by login; local lockout counters are preserved).
     */
    public static class EmployeeDto {
        /** The login (upsert key). */
        public String loginName;
        /** The first name. */
        public String firstName;
        /** The last name. */
        public String lastName;
        /** The password hash. */
        public String password;
        /** The email. */
        public String email;
        /** The role name. */
        public String role;
        /** The badge id, or null. */
        public String badgeId;
        /** The personal display theme, or null (follows the store). */
        public String theme;
        /** Interface language administered for this employee, or null (BO-01-01-04). */
        public String language;
        /** When the secret was last changed, ISO-8601, or null (BO-01-02-12). */
        public String passwordChangedAt;
        /** Whether the employee is active. */
        public boolean active;
    }

    /**
     * A back-office parameter (upsert by key; an absent key means the
     * register reverts to the catalog default).
     */
    public static class SettingDto {
        /** The parameter key (upsert key). */
        public String key;
        /** The parameter value, as text. */
        public String value;
    }

    /**
     * A verbatim engine feed (upsert by code): the raw CSV parcel shipped
     * unopened from the store node to the registers for their local
     * valuation engine. The version is the SHA-256 of the content.
     */
    public static class EngineFeedDto {
        /** The feed code (upsert key). */
        public String code;
        /** The content version (SHA-256 hex). */
        public String version;
        /** The raw CSV content, verbatim. */
        public String content;
    }

    /**
     * A country echelon (upsert by code) pulled by a store node from the
     * central node (domain COUNTRIES). Top of the organisation tree.
     */
    public static class CountryDto {
        /** The country code (upsert key). */
        public String code;
        /** The country name. */
        public String name;
        /** The default language, or null. */
        public String defaultLanguage;
    }

    /**
     * An enseigne echelon (upsert by code) pulled by a store node from the
     * central node (domain ENSEIGNES). Attached to a country by code.
     */
    public static class EnseigneDto {
        /** The enseigne code (upsert key). */
        public String code;
        /** The enseigne name. */
        public String name;
        /** The code of the country it hangs under, or null. */
        public String countryCode;
        /** The default language, or null. */
        public String defaultLanguage;
    }

    /**
     * A point de vente (upsert by number) pulled by a store node from the
     * central node (domain PDVS). Attached to an enseigne by code.
     */
    public static class PdvDto {
        /** The five-digit PDV number (upsert key). */
        public String pdvNumber;
        /** The PDV name. */
        public String name;
        /** The code of the enseigne it hangs under, or null. */
        public String enseigneCode;
        /** The adhérent grouping code, or null. */
        public String adherentCode;
        /** Whether the PDV is active. */
        public boolean active;
    }

    /**
     * A back-office parameter posed at an echelon (upsert by the triplet
     * level/code/key) pulled by a store node from the central node (domain
     * ECHELON_SETTINGS). Carries the effect date the value applies from.
     */
    public static class EchelonSettingDto {
        /** The echelon level name (COUNTRY, ENSEIGNE or PDV). */
        public String level;
        /** The echelon code at that level (part of the upsert key). */
        public String echelonCode;
        /** The catalog key (part of the upsert key). */
        public String settingKey;
        /** The value, as text. */
        public String settingValue;
        /** The effect date (ISO-8601 yyyy-MM-dd), or null for immediate effect. */
        public String effectiveDate;
    }

    /**
     * A coupon type (upsert by code).
     */
    public static class CheckoutIslandDto {
        /** The island code (upsert key). */
        public String code;
        /** The display label. */
        public String label;
        /** Whether the island is in service. */
        public boolean active;
        /** The attached registers, as a semicolon list of terminal identifiers. */
        public String terminalIds;
    }

    /**
     * One administered CHECKOUT POINT — a register seen from the back office
     * (BO-03-09, BO-03-10), with the attributes the lane cannot know about
     * itself: its island, its kind, its hostess, its two displays, its menu.
     *
     * <p>The snapshot is GLOBAL and not filtered to the terminal that asks: a
     * register receives every point of its store, because the technical hostess
     * supervises the self-service points beside her, the remote close names
     * another register, and the island's composition is read here. Filtering
     * would save a handful of rows and remove all three.
     *
     * <p>Enumerations travel by their NAME in text, like every other enum on
     * this wire, never by their ordinal: a value inserted in the middle of an
     * enum would otherwise silently renumber what the registers already hold.
     */
    public static class CheckoutPointDto {
        /** The register identifier ({@code pos.terminal.id}), the upsert key. */
        public String terminalId;
        /** The point-of-vente number the register belongs to, or null. */
        public String pdvNumber;
        /** The code of the island the register belongs to, or null. */
        public String islandCode;
        /** The human-readable label shown in the back office. */
        public String label;
        /** Whether the register is in service (BO-03-09-01). */
        public boolean active;
        /** The kind of checkout point (BO-03-09-07), by name. */
        public String tpvType;
        /** The badge of the technical hostess (BO-03-09-08), or null. */
        public String technicalHostessBadge;
        /** The type of the cashier display (BO-03-09-12), by name. */
        public String cashierDisplayType;
        /** The resolution of the cashier display, free text, or null. */
        public String cashierDisplayResolution;
        /** The type of the customer display (BO-03-09-13), by name. */
        public String customerDisplayType;
        /** The resolution of the customer display, free text, or null. */
        public String customerDisplayResolution;
        /** The protocol of the attached scale (BO-03-09-15), by name. */
        public String scaleProtocol;
        /** Where the scale answers (BO-03-09-15), or null. */
        public String scaleAddress;
        /** The port the scale answers on (BO-03-09-15), or null. */
        public Integer scalePort;
        /** The protocol of the attached coin machine (BO-03-09-24/-25/-26), by name. */
        public String coinMachineProtocol;
        /** Where the coin machine answers, or null. */
        public String coinMachineAddress;
        /** The port the coin machine answers on, or null. */
        public Integer coinMachinePort;
        /** The code of the cash-menu model assigned (BO-03-10-16), or null. */
        public String menuTemplateCode;
    }

    /**
     * ONE PROVIDER MESSAGE translated into the shop's words (BO-03-08-06
     * and -07).
     */
    public static class ProviderMessageDto {
        /** The provider the code comes from (half of the upsert key). */
        public String providerCode;
        /** The code the provider answers (the other half). */
        public String messageCode;
        /** What the cashier reads, or null to keep the provider's text. */
        public String screenText;
        /** What the ticket prints, or null to print nothing. */
        public String ticketText;
        /** Whether the substitution is applied. */
        public boolean active;
    }

    /**
     * One administered DOCUMENT TEMPLATE — the layout of one printed document
     * (BO-03-03).
     */
    public static class DocumentTemplateDto {
        /** The template code (upsert key). */
        public String code;
        /** The display label. */
        public String label;
        /** The document the template lays out. */
        public String documentType;
        /** Whether the template is used. */
        public boolean active;
        /** The order competing templates of one document type are tried in. */
        public int priority;
        /** The width the template lays out for, in characters. */
        public int width;
        /** How many copies of the document are printed. */
        public int copies;
        /** The Qute source. */
        public String source;
        /** The administered name of the document, null when the register's own stands. */
        public String title;
        /** The administered name of a REPRINT, null when the register's own stands. */
        public String duplicateTitle;
        /** The prefix the document's number carries, null when none. */
        public String numberPrefix;
        /** The name of each printed copy, in order, separated by semicolons. */
        public String copyTitles;
    }

    /**
     * One administered TENDER — a settlement method put in service and bounded
     * (BO-03-02-03/04/10 to 30).
     */
    public static class TenderDefinitionDto {
        /** The settlement key, equal to the payment discriminator (upsert key). */
        public String code;
        /** The functional identifier administered by the store. */
        public String functionalId;
        /** The display label. */
        public String label;
        /** Code of the group the method is totalled under (BO-06-06-09), or null. */
        public String groupCode;
        /** Label of that group (BO-06-06-09), or null. */
        public String groupLabel;
        /** Whether the tender is in service. */
        public boolean active;
        /** The order the tenders are offered in. */
        public int displayOrder;
        /** The first ceiling of one settlement, or null when unbounded. */
        public String maxAmount;
        /** What the register does when the first ceiling is exceeded. */
        public String maxAmountControl;
        /** The second ceiling of one settlement, or null when unbounded. */
        public String secondMaxAmount;
        /** What the register does when the second ceiling is exceeded. */
        public String secondMaxAmountControl;
        /** The floor of one settlement, or null when unbounded. */
        public String minAmount;
        /** What the register does when the floor is not reached. */
        public String minAmountControl;
        /** How many settlements of this tender one sale may carry, or null. */
        public Integer maxCount;
        /** What the register does when the count is reached. */
        public String maxCountControl;
        /** The largest change this tender may give back, or null. */
        public String maxChangeAmount;
        /** What the register does when the change ceiling is exceeded. */
        public String maxChangeControl;
        /** Whether the tender may be used to refund a customer. */
        public boolean refundAllowed;
        /** Whether an overpayment on this tender gives change back. */
        public boolean changeAllowed;
        /** The tender the change is given in, or null for the tender itself. */
        public String changeTenderCode;
        /** The VIC product code of the multi-product card (BO-03-09-30), or null. */
        public String vicProductCode;
        /** Whether a self-service lane may settle with this tender (BO-03-02-27). */
        public boolean selfServiceAllowed = true;
        /** Whether settling with it on a self-service lane calls the hostess (BO-03-02-29). */
        public boolean selfServiceSupervision;
        /** Whether the cashier's holding is declared automatically. */
        public boolean cashierDeclaration;
        /** Whether this tender is withdrawn from the drawer automatically. */
        public boolean automaticWithdrawal;
        /** When the cash drawer opens for this tender. */
        public String drawerOpening;
        /** Whether cash movements may use this tender. */
        public boolean movementAllowed;
        /** Whether the takings of this tender are deposited at the bank. */
        public boolean bankDeposit;
        /** Whether this tender may make up the opening float. */
        public boolean floatAllowed;
        /** Whether the remaining due is pre-filled when this tender is picked. */
        public boolean defaultsToTotal;
        /** Whether the withdrawal report details this tender. */
        public boolean withdrawalReportDetail;
        /** Whether the use of this tender is reported to the fidelity programme. */
        public boolean fidelityReported;
        /** The gabarit printed when this tender is used, or null. */
        public String documentTemplateCode;
        /** How many times that slip is printed. */
        public int printCount;
        /** Whether a duplicate of that slip is printed beside it. */
        public boolean printDuplicate;
        /** Whether that slip is printed even when the receipt is not. */
        public boolean printForced;
    }

    /**
     * One administered ARTICLE barcode range (BO-03-06-02/03/04/05/10).
     */
    public static class ArticleBarcodeRangeDto {
        /** The range code (upsert key). */
        public String code;
        /** The display label. */
        public String label;
        /** Whether the range is considered at scan time. */
        public boolean active;
        /** The order the ranges are tested in. */
        public int priority;
        /** The literal head every code of the range carries. */
        public String prefix;
        /** The total code length. */
        public int codeLength;
        /** The character kind outside the two administered segments. */
        public String codeKind;
        /** The 0-based offset of the segment naming the article. */
        public int articlePosition;
        /** The number of characters of the article segment. */
        public int articleLength;
        /** What the value segment carries (PRICE or WEIGHT). */
        public String valueSource;
        /** The 0-based offset of the segment carrying the value. */
        public int valuePosition;
        /** The number of characters of the value segment. */
        public int valueLength;
        /** The number of decimals the value segment carries. */
        public int valueDecimals;
        /** The currency a PRICE segment is expressed in. */
        public String currency;
        /** Whether the last character is a verified check digit. */
        public boolean checkDigit;
        /** The generated recognition pattern. */
        public String matchPattern;
        /** What the register does with a code of the range (BO-03-06-56/-60/-61). */
        public String purpose;
        /** The promotion a PROMOTION range names (BO-03-06-43), or null. */
        public String promotionCode;
        /** The third-party service an EXTERNAL_LOOKUP range asks (BO-03-06-41), or null. */
        public String lookupUrl;
    }

    /**
     * One administered voucher range (BO-03-06).
     */
    public static class CouponTypeDto {
        /** The type code (upsert key). */
        public String code;
        /** The display label. */
        public String label;
        /** The recognition regex, or empty for numberless types. */
        public String matchPattern;
        /** The amount source name (ENCODED or MANUAL). */
        public String amountSource;
        /** The amount extraction regex, or null. */
        public String amountPattern;
        /** The matching priority. */
        public int priority;
        /** Whether the type is active. */
        public boolean active;
        /** Whether the type is a deposit-return line type. */
        public boolean depositLine;
        /** The literal head every code of the range carries, or null. */
        public String prefix;
        /** The total code length, or null when the range is not administered. */
        public Integer codeLength;
        /** The character kind outside the administered fields, or null. */
        public String codeKind;
        /** Whether an all-nines price means "ask the cashier" (BO-03-06-12). */
        public boolean manualAmountOnAllNines;
        /** The checkout islands accepting the range, or null for all (BO-03-06-07). */
        public String islandCodes;
        /** The administered positions of the range, empty when there are none. */
        public List<CouponFieldDto> fields = new ArrayList<>();
        /** The administered controls of the range, empty when there are none. */
        public List<CouponControlDto> controls = new ArrayList<>();
    }

    /**
     * One administered control of a barcode range (BO-03-06): what the register
     * checks, how loudly it reacts and what it says. A control is what gives an
     * administered position a reader, so it travels with the type.
     */
    public static class CouponControlDto {
        /** The control kind name, which is also its key within its type. */
        public String kind;
        /** The alert level name. */
        public String level;
        /** The administered wording, or null for the control's own. */
        public String message;
    }

    /**
     * One administered position of a barcode range (BO-03-06): where a value
     * sits in the code and how to read it. The recognition pattern of the
     * owning type is generated from these rows, so they travel with it.
     */
    public static class CouponFieldDto {
        /** The role name, which is also the field's key within its type. */
        public String role;
        /** The zero-based position of the field's first character. */
        public int offsetPosition;
        /** The number of characters the field spans. */
        public int fieldLength;
        /** The character kind name. */
        public String kind;
        /** The decimal count of a monetary field, or null for the default. */
        public Integer decimals;
        /** The date or time layout name, or null. */
        public String dateFormat;
        /** The currency name of a price field, or null for euros. */
        public String currency;
    }

    /**
     * An account customer as the commercial management holds it, pulled by the
     * register ({@code LC-07-09}).
     *
     * <p>The register can CREATE such a customer at the till (the invoice flow does)
     * and pushes it upward on the outbox, but the credit ceiling and the outstanding
     * balance travel the other way only: they are the shop's figures, and a register
     * that could raise its own ceiling would not be a control.
     */
    public static class CustomerDto {
        /** The account number (upsert key). */
        public String accountNumber;
        /** The business name. */
        public String companyName;
        /** Where the customer came from: REGISTER or INTEGRATED (BO-02-04-22). */
        public String origin;
        /** The contact's civility, or null (BO-02-04-02). */
        public String civility;
        /** The contact's family name, or null. */
        public String lastName;
        /** The contact's given name, or null. */
        public String firstName;
        /** The street line of the billing address, or null. */
        public String street;
        /** The postal code of the billing address, or null. */
        public String postalCode;
        /** The city of the billing address, or null. */
        public String city;
        /** The SIRET, or null. */
        public String siret;
        /** The intra-community VAT number, or null. */
        public String vatNumber;
        /** The telephone number, or null. */
        public String phone;
        /** The electronic address, or null. */
        public String email;
        /** The fiscal identifier (NIF), or null (BO-02-04-18/20). */
        public String taxId;
        /** The commercial segment, or null (BO-10-04-07). */
        public String segment;
        /** True when the account is blocked at the register (BO-02-04-06). */
        public boolean blocked;
        /** The due date as {@code yyyy-MM-dd}, or null (BO-02-04-08). */
        public String dueDate;
        /** The granted discount in percent, or null (BO-02-04-09). */
        public String discountPercent;
        /** The administered credit ceiling, or null when credit is not granted. */
        public String creditLimit;
        /** The outstanding balance, or null for none. */
        public String creditBalance;
        /** The free fields the commercial management filled (BO-02-04-11). */
        public List<FreeFieldDto> freeFields = new ArrayList<>();
    }

    /**
     * One free field of a customer in account ({@code BO-02-04-11}).
     */
    public static class FreeFieldDto {
        /** The slot the commercial management numbers the field by. */
        public int slot;
        /** The label shown in front of the value, or null. */
        public String label;
        /** The value, or null. */
        public String value;
    }

    /**
     * A postal code and the place it designates ({@code BO-02-04-15/16/21}).
     *
     * <p>Upserted on the PAIR and not on the code: a French code covers several
     * communes and a Portuguese one covers a street, so keying on the code
     * alone would keep one of them and lose the rest.
     */
    public static class PostalCodeDto {
        /** The postal code. */
        public String code;
        /** The place it designates. */
        public String place;
        /** The ISO country, or null. */
        public String country;
    }

    /**
     * A foreign currency the shop accepts, with the rate it applies
     * ({@code LC-07-14}).
     */
    public static class CurrencyDto {
        /** The ISO code (upsert key). */
        public String code;
        /** The name shown to the cashier. */
        public String label;
        /** The symbol printed beside an amount, or null. */
        public String symbol;
        /** How many euros one unit is worth, as text to keep the row canonical. */
        public String euroPerUnit;
        /** Whether the till offers it. */
        public boolean active;
        /** The order it appears in on the payment screen. */
        public int displayOrder;
        /** The tender the change is given in, or null for euros. */
        public String changeTenderCode;
    }

    /**
     * An administered NAMED LIST and its entries ({@code BO-04-02-07},
     * {@code BO-04-03-12}): the service-request reasons, the justifications,
     * the return types and the tare containers, which used to travel as four
     * semicolon-separated settings.
     *
     * <p>The entries ride INSIDE the list rather than as a domain of their
     * own, like the free fields of a customer: a list without its entries is
     * not a half-applied list, it is a wrong one, and the two must land in
     * the same transaction.
     */
    public static class PosListDto {
        /** The list code (upsert key). */
        public String code;
        /** The heading the entries are grouped under. */
        public String label;
        /** What the list drives: SERVICE_REQUEST, JUSTIFICATION, RETURN_TYPE or TARE_CONTAINER. */
        public String kind;
        /** The register functions it serves, semicolon-separated, or null for all. */
        public String functions;
        /** Whether the list is offered at all. */
        public boolean active;
        /** The entries, in display order; never null on the wire. */
        public java.util.List<PosListItemDto> items;
    }

    /**
     * ONE entry of an administered list. What it carries besides its label
     * depends on the kind of its list: a severity for a service request, a
     * weight for a tare container, option markers for a return type.
     */
    public static class PosListItemDto {
        /** The entry code, unique inside its list. */
        public String code;
        /** What the key is called in front of the cashier. */
        public String label;
        /** The rank the entry is drawn at, lowest first. */
        public int displayOrder;
        /** The priority of a service request, 0 when unused. */
        public int severity;
        /** The weight of a tare container in kilograms, as text, or null. */
        public String numericValue;
        /** The option markers of a return type, comma-separated, or null. */
        public String options;
        /** Whether the entry is offered at all. */
        public boolean active;
    }

    /**
     * An administered IMAGE resolved for the asking store
     * ({@code BO-03-03-15}, {@code BO-10-03-09}): the receipt logo, or the
     * visual of a loyalty advantage.
     *
     * <p>THE ECHELON IS NOT ON THE WIRE. The store node resolves the chain —
     * PDV, enseigne, country, group default — and sends the winner, exactly
     * as it sends resolved parameters and never the echelon rows.
     */
    public static class StoreImageDto {
        /** The image code (upsert key). */
        public String code;
        /** What the administrator calls it. */
        public String label;
        /** What it is for: RECEIPT_LOGO or LOYALTY_ADVANTAGE. */
        public String usage;
        /** The loyalty advantage it illustrates, or null for a logo. */
        public String advantageCode;
        /** The image itself, a PNG {@code data:} URI. */
        public String imageData;
        /** Whether the register uses it at all. */
        public boolean active;
    }
}
